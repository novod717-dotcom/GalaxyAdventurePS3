#ifndef GA_GAME_H
#define GA_GAME_H
#include <stdint.h>
#define GA_MAX_PLANETS 4
#define GA_MAX_ENEMIES 8
#define GA_MAX_STARS 12
#define GA_LEVELS 3

typedef struct { float x,y,z; } Vec3;
typedef enum { MODE_TITLE, MODE_PLAYING, MODE_PAUSED, MODE_LEVEL_CLEAR, MODE_GAME_OVER } GameMode;
typedef struct { Vec3 center; float radius; int active; } Planet;
typedef struct { Vec3 position, velocity; float radius; int active, health; } Enemy;
typedef struct { Vec3 position; int active, collected; } Collectible;
typedef struct { Vec3 position, velocity, up; int grounded; float yaw; } Player;
typedef struct { Vec3 position, target; float distance; } Camera;
typedef struct {
 float move_x, move_y; int jump_pressed, pause_pressed, confirm_pressed, back_pressed;
} GameInput;
typedef struct {
 GameMode mode; Player player; Camera camera;
 Planet planets[GA_MAX_PLANETS]; Enemy enemies[GA_MAX_ENEMIES];
 Collectible stars[GA_MAX_STARS];
 int level, lives, stars_total, stars_found, boss_health, boss_active;
 float elapsed, level_time, invulnerability;
} GameState;
typedef struct { int level, lives, stars_found; uint32_t magic; } SaveData;
void game_init(GameState *g);
void game_update(GameState *g, const GameInput *in, float dt);
void game_start_level(GameState *g, int level);
int game_save(const GameState *g, const char *path);
int game_load(GameState *g, const char *path);
Vec3 vec3_normalize(Vec3 v);
float vec3_length(Vec3 v);
#endif
