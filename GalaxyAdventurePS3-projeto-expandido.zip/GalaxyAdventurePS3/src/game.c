#include "game.h"
#include <math.h>
#include <string.h>
#include <stdio.h>
#define PI 3.14159265358979323846f
static Vec3 add(Vec3 a,Vec3 b){return (Vec3){a.x+b.x,a.y+b.y,a.z+b.z};}
static Vec3 sub(Vec3 a,Vec3 b){return (Vec3){a.x-b.x,a.y-b.y,a.z-b.z};}
static Vec3 mul(Vec3 a,float s){return (Vec3){a.x*s,a.y*s,a.z*s};}
static float dot(Vec3 a,Vec3 b){return a.x*b.x+a.y*b.y+a.z*b.z;}
float vec3_length(Vec3 v){return sqrtf(dot(v,v));}
Vec3 vec3_normalize(Vec3 v){float n=vec3_length(v);return n<0.00001f?(Vec3){0,1,0}:mul(v,1.0f/n);}
static float clampf(float x,float a,float b){return x<a?a:(x>b?b:x);}
static int near3(Vec3 a,Vec3 b,float d){return vec3_length(sub(a,b))<d;}
static Vec3 tangent_forward(Vec3 up){Vec3 f={0,0,-1};if(fabsf(dot(f,up))>0.95f)f=(Vec3){1,0,0};return vec3_normalize(sub(f,mul(up,dot(f,up))));}

void game_start_level(GameState *g,int level){
 if(level<0)level=0;if(level>=GA_LEVELS)level=GA_LEVELS-1;
 g->level=level;g->level_time=0;g->boss_health=3;g->boss_active=1;
 memset(g->planets,0,sizeof(g->planets));memset(g->enemies,0,sizeof(g->enemies));memset(g->stars,0,sizeof(g->stars));
 g->planets[0]=(Planet){{0,0,0},12.0f,1};
 g->planets[1]=(Planet){{25,3,-14},6.0f,1};
 g->planets[2]=(Planet){{-23,-2,-25},8.0f,1};
 g->planets[3]=(Planet){{0,20,-43},5.0f,level>0};
 g->player.position=(Vec3){0,13,0};g->player.velocity=(Vec3){0,0,0};g->player.grounded=1;g->player.yaw=0;
 g->camera.distance=13;g->camera.target=g->player.position;g->camera.position=(Vec3){0,22,15};
 for(int i=0;i<GA_MAX_STARS;i++){
  int p=i%3;float a=(float)i*2.39996323f;float r=g->planets[p].radius+1.8f;
  Vec3 c=g->planets[p].center;g->stars[i].position=add(c,(Vec3){cosf(a)*r,0.8f,sinf(a)*r});
  g->stars[i].active=(i<4+level*2);g->stars[i].collected=0;
 }
 for(int i=0;i<GA_MAX_ENEMIES;i++){
  int p=i%3;float a=(float)i*0.91f;float r=g->planets[p].radius+0.7f;
  g->enemies[i].position=add(g->planets[p].center,(Vec3){cosf(a)*r,0.7f,sinf(a)*r});
  g->enemies[i].active=(i<2+level);g->enemies[i].health=1;g->enemies[i].radius=0.9f;
 }
}
void game_init(GameState *g){memset(g,0,sizeof(*g));g->mode=MODE_TITLE;g->lives=3;game_start_level(g,0);g->mode=MODE_TITLE;}
static int nearest_planet(const GameState *g,Vec3 p){int best=0;float bd=1e30f;for(int i=0;i<GA_MAX_PLANETS;i++)if(g->planets[i].active){float d=vec3_length(sub(p,g->planets[i].center))-g->planets[i].radius;if(d<bd){bd=d;best=i;}}return best;}
static void update_camera(GameState *g,float dt){Vec3 up=g->player.up;Vec3 back=mul(tangent_forward(up),-g->camera.distance);Vec3 desired=add(g->player.position,add(mul(up,6.0f),back));float k=clampf(dt*4.0f,0,1);g->camera.position=add(mul(g->camera.position,1-k),mul(desired,k));g->camera.target=add(g->player.position,mul(up,1.0f));}
static void damage_player(GameState *g){if(g->invulnerability>0)return;g->lives--;g->invulnerability=1.8f;if(g->lives<=0){g->mode=MODE_GAME_OVER;return;}g->player.position=(Vec3){0,13,0};g->player.velocity=(Vec3){0,0,0};g->player.grounded=1;}
void game_update(GameState *g,const GameInput *in,float dt){
 if(!g||!in||dt<=0)return;dt=clampf(dt,0,0.04f);g->elapsed+=dt;if(g->invulnerability>0)g->invulnerability-=dt;
 if(g->mode==MODE_TITLE){if(in->confirm_pressed)g->mode=MODE_PLAYING;return;}
 if(g->mode==MODE_GAME_OVER){if(in->confirm_pressed){g->lives=3;g->stars_found=0;game_start_level(g,0);g->mode=MODE_PLAYING;}return;}
 if(g->mode==MODE_LEVEL_CLEAR){if(in->confirm_pressed){if(g->level+1<GA_LEVELS){game_start_level(g,g->level+1);g->mode=MODE_PLAYING;}else g->mode=MODE_TITLE;}return;}
 if(in->pause_pressed){g->mode=(g->mode==MODE_PAUSED)?MODE_PLAYING:MODE_PAUSED;return;}if(g->mode==MODE_PAUSED)return;
 g->level_time+=dt;
 int pi=nearest_planet(g,g->player.position);Planet *pl=&g->planets[pi];Vec3 up=vec3_normalize(sub(g->player.position,pl->center));g->player.up=up;
 Vec3 f=tangent_forward(up),r=vec3_normalize((Vec3){f.y*up.z-f.z*up.y,f.z*up.x-f.x*up.z,f.x*up.y-f.y*up.x});
 Vec3 wish=add(mul(r,in->move_x),mul(f,-in->move_y));float wl=vec3_length(wish);if(wl>1)wish=mul(wish,1/wl);
 float radial=dot(g->player.velocity,up);Vec3 tv=sub(g->player.velocity,mul(up,radial));Vec3 desired=mul(wish,7.0f);float blend=clampf(dt*9,0,1);tv=add(mul(tv,1-blend),mul(desired,blend));
 g->player.velocity=add(tv,mul(up,radial-22.0f*dt));if(in->jump_pressed&&g->player.grounded){g->player.velocity=add(g->player.velocity,mul(up,9.0f));g->player.grounded=0;}
 g->player.position=add(g->player.position,mul(g->player.velocity,dt));Vec3 rel=sub(g->player.position,pl->center);float floor=pl->radius+1.0f;float dist=vec3_length(rel);
 if(dist<floor){Vec3 n=vec3_normalize(rel);g->player.position=add(pl->center,mul(n,floor));float inward=dot(g->player.velocity,n);if(inward<0)g->player.velocity=sub(g->player.velocity,mul(n,inward));g->player.grounded=1;}
 for(int i=0;i<GA_MAX_STARS;i++)if(g->stars[i].active&&!g->stars[i].collected&&near3(g->player.position,g->stars[i].position,1.7f)){g->stars[i].collected=1;g->stars_found++;}
 for(int i=0;i<GA_MAX_ENEMIES;i++)if(g->enemies[i].active&&near3(g->player.position,g->enemies[i].position,1.35f)){if(g->player.velocity.y< -1.0f){g->enemies[i].active=0;g->player.velocity=add(g->player.velocity,mul(up,6));}else damage_player(g);}
 if(g->boss_active&&g->stars_found>=3+g->level*2&&near3(g->player.position,(Vec3){0,13,-43},4.0f)){g->boss_health--;g->player.velocity=add(g->player.velocity,mul(up,5));if(g->boss_health<=0)g->boss_active=0;}
 if(!g->boss_active)g->mode=MODE_LEVEL_CLEAR;
 update_camera(g,dt);
}
int game_save(const GameState *g,const char *path){if(!g||!path)return 0;SaveData d={g->level,g->lives,g->stars_found,0x47415356u};FILE *f=fopen(path,"wb");if(!f)return 0;int ok=fwrite(&d,sizeof(d),1,f)==1;fclose(f);return ok;}
int game_load(GameState *g,const char *path){if(!g||!path)return 0;SaveData d;FILE *f=fopen(path,"rb");if(!f)return 0;int ok=fread(&d,sizeof(d),1,f)==1;fclose(f);if(!ok||d.magic!=0x47415356u||d.level<0||d.level>=GA_LEVELS)return 0;game_start_level(g,d.level);g->lives=d.lives;g->stars_found=d.stars_found;g->mode=MODE_TITLE;return 1;}
