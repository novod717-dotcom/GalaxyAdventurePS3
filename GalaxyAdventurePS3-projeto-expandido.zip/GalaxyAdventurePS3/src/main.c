#include "game.h"
#include <stdio.h>
int main(void){GameState g;GameInput in={0};game_init(&g);printf("Galaxy Adventure - simulation test\n");in.confirm_pressed=1;game_update(&g,&in,1.0f/60);in.confirm_pressed=0;in.move_x=0.25f;in.move_y=0.6f;for(int i=0;i<600;i++){in.jump_pressed=(i%100==0);game_update(&g,&in,1.0f/60);}printf("Level %d | lives %d | stars %d | elapsed %.1fs\n",g.level+1,g.lives,g.stars_found,g.elapsed);printf("Player: %.2f %.2f %.2f\n",g.player.position.x,g.player.position.y,g.player.position.z);return 0;}
