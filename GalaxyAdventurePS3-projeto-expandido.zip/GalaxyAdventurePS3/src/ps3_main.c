/*
 * PS3 front-end integration point.
 * Connect this game simulation to PSL1GHT's video/RSX and ioPad samples.
 * The game simulation is platform-independent; this adapter is intentionally
 * not advertised as a finished renderer or a bootable PS3 executable yet.
 */
#include "game.h"
int galaxy_ps3_start(void){GameState game;GameInput input={0};game_init(&game);(void)input;(void)game;return 0;}
