#include "game.h"
#include <assert.h>
#include <stdio.h>
int main(void){GameState g;GameInput in={0};game_init(&g);assert(g.mode==MODE_TITLE);in.confirm_pressed=1;game_update(&g,&in,1.0f/60);assert(g.mode==MODE_PLAYING);in.confirm_pressed=0;in.pause_pressed=1;game_update(&g,&in,1.0f/60);assert(g.mode==MODE_PAUSED);in.pause_pressed=1;game_update(&g,&in,1.0f/60);assert(g.mode==MODE_PLAYING);assert(game_save(&g,"test_save.bin"));assert(game_load(&g,"test_save.bin"));remove("test_save.bin");puts("All game logic tests passed.");return 0;}
